# Basic Example

A simple [create-react-app](CRA-README.md) setup, showcasing one of the lastest React-Bootstrap components!
"homepage": "https://github.com/Thieuquangtruong/React-Shopping-Cart/tree/l16-deployment/",