import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import Card from "react-bootstrap/Card";

function ProductDetail() {
  const [product, setProduct] = useState(null);
  const { productId } = useParams();

  console.log("productId", productId);

  //Get Data
  useEffect(() => {
    fetch("https://63ac467634c46cd7ae7cce54.mockapi.io/api/mindx/products/")
      .then((res) => res.json())
      .then((products) => {
        console.log("products", products);
        const temp = products.find((e) => e.id == productId);
        console.log("temp", temp);
        setProduct(temp);
      });
  }, []);

  return (
    <>
      {product && (
        <Card style={{ paddingTop: "55px", width: "18.8rem", background: "white" }}>
          <Card.Img variant="top" src={`{product.productImg}`} />
          <Card.Body>
            <Card.Title>{product.productTitle}</Card.Title>
            <Card.Text>Giá Sản Phẩm : {product.productPrice}</Card.Text>
          </Card.Body>
        </Card>
      )}
    </>
  );
}

export default ProductDetail;
