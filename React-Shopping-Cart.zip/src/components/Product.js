import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";
import { NavLink } from "react-router-dom";

export default function Products({
  type,
  productImg,
  productTitle,
  productPrice,
  onSubmit,
  productId,
})


{

  return (
    <div className="product">
      <NavLink to={`/cart/${productId}`}>
        <Card style={{ width: "18.8rem", background: "white" }}>
          <Card.Img variant="top" src={productImg} />
          <Card.Body>
            <Card.Title>{productTitle}</Card.Title>
            <Card.Text>Giá Sản Phẩm : {productPrice}VNĐ</Card.Text>
            
          </Card.Body>
        </Card>
      </NavLink>
      <Button className="btn-add" variant="primary" onClick={onSubmit}>
              {type === "PRODUCT" ? "Add to cart" : "Remove"}
            </Button>
    </div>
  );
}
